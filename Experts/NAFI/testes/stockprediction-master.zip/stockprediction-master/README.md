# A simple deep learning model for stock prediction using TensorFlow

This repository contains the Python script as well as the source dataset from my Medium.com article ["A simple deep learning model for stock prediction using TensoFlow"](https://medium.com/mlreview/a-simple-deep-learning-model-for-stock-price-prediction-using-tensorflow-30505541d877).

Please note, that the dataset is zipped due to Github file size restrictions. Feel free to clone and fork! :)

If you need any help in developing deep learning models in Python and TensorFlow contact my ["data science consulting company STATWORX"](https://www.statworx.com/de/data-science/).
