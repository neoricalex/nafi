from evostra.algorithms import EvolutionStrategy
from evostra.models import FeedForwardNetwork
