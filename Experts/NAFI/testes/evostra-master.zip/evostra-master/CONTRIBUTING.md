Feel free to contribute to this project. 
And make sure your code is compatible with both python versions 2 and 3. 💙
